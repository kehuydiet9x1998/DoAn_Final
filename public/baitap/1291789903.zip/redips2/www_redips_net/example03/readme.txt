Darko Bunic
http://www.redips.net/
Feb, 2010.

This example shows how to arrange timetable and save to the MySQL database.
Database communication is concentrated in config.php which is included in index.php and save.php 

Before start using this example you should:
1) create two tables: redips_subject and redips_timetable (see database.sql)
2) define database name, user and password in config.php

After steps are finished, empty timetable should appear and you can start drag subjects.
Happy dragging and dropping!